﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nim
{
    class Program
    {
        static void Main(string[] args)
        {
            Game m = new Game();
        }
    }
}
